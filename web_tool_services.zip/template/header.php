
<div class="bg-primary position-relative">
  <div class="overlay-gradient"></div>
  <div class="container position-relative">
  	<div class="row py-5">
    	<div class="col">
        <h1 class="display-1">Welcome, <?php echo $_SESSION['username']; ?></h1>
        <p>You can generate your QR Code for totaly free.</p>
        <p><a href="logout.php" class="btn btn-primary btn-lg shadow" role="button">Logout&raquo;</a></p>
    </div>
    </div>
  </div>
</div>